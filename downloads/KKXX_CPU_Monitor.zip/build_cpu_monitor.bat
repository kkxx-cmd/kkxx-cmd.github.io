@echo off
chcp 65001 >nul
echo ========================================
echo   KKXX CPU Monitor 打包工具
echo ========================================
echo.

echo [1/4] 安装依赖...
pip install psutil pillow pystray pywin32 wmi
if errorlevel 1 (
    echo   依赖安装失败，请以管理员身份运行！
    pause
    exit /b 1
)
echo   OK

echo [2/4] 安装打包工具...
pip install pyinstaller
if errorlevel 1 (
    echo   pyinstaller 安装失败
    pause
    exit /b 1
)
echo   OK

echo [3/4] 打包中（请耐心等待）...
pyinstaller --onefile --noconsole --name "KKXX_CPU_Monitor" --distpath "D:\" cpu_tray_monitor.py
if errorlevel 1 (
    echo   打包失败
    pause
    exit /b 1
)
echo   OK

echo.
echo ========================================
echo   打包完成！
echo   exe 文件: D:\KKXX_CPU_Monitor.exe
echo   首次运行会自动开启开机自启
echo ========================================
echo.
echo 按任意键打开 D:\ 盘...
explorer D:\
pause