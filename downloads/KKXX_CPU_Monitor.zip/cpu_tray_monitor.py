#!/usr/bin/env python3
"""
KKXX CPU Monitor - 系统托盘悬浮窗
显示 CPU 温度 + 占用率，占用极低资源，开机自启
Python 3.8+
依赖: pip install psutil pillow pystray pywin32
打包: pyinstaller --onefile --noconsole cpu_tray.py
"""

import os, sys, time, threading, winreg, subprocess
from ctypes import byref, c_ulong, POINTER, Structure
from functools import lru_cache

# ---- 依赖检测 ----
try:
    import psutil
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "psutil", "pillow", "pystray", "pywin32"], check=True)
    import psutil

from PIL import Image, ImageDraw, ImageFont
import pystray

# ---- 托盘图标绘制 ----
def make_icon_text(text: str, size=64) -> Image:
    """生成带文字的圆形图标"""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # 圆形背景
    draw.ellipse([2, 2, size - 3, size - 3], fill=(55, 100, 220, 230))
    # 文字
    try:
        font = ImageFont.truetype("msyh.ttc", 20)
    except Exception:
        font = ImageFont.load_default()
    draw.text((size // 2, size // 2), text, font=font, fill=(255, 255, 255, 255), anchor="mm")
    return img

# ---- CPU 数据获取 ----
class CPUMonitor:
    # Windows COM 接口，读取 WMI 温度
    class RawSMBIOSData(Structure):
        _fields_ = [("UsedBytes", c_ulong)]

    @staticmethod
    @lru_cache(maxsize=1)
    def get_cpu_usage() -> float:
        """获取 CPU 占用率（缓存1秒）"""
        return psutil.cpu_percent(interval=0.1)

    @staticmethod
    def get_cpu_temperature() -> float:
        """获取 CPU 温度（优先 WMI，其次注册表）"""
        t = CPUMonitor._wmi_temperature()
        if t is not None:
            return t
        return CPUMonitor._registry_temperature()

    @staticmethod
    def _wmi_temperature() -> float | None:
        """通过 WMI 获取 CPU 温度"""
        try:
            import wmi
            w = wmi.WMI()
            for o in w.MSAcpi_ThermalZoneTemperature():
                t = float(o.CurrentTemperature) / 10.0 - 273.15
                if 20 < t < 110:
                    return t
        except Exception:
            pass
        return None

    @staticmethod
    def _registry_temperature() -> float | None:
        """从注册表读取 CPU 温度（部分主板有效）"""
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Services\Thermal\\Zone Temperature", 0)
            val, _ = winreg.QueryValueEx(key, "CurrentTemperature")
            winreg.CloseKey(key)
            if val:
                return float(val) / 10.0 - 273.15
        except Exception:
            pass
        return None

# ---- 托盘菜单 ----
def build_menu(usage: float, temp: float | None):
    temp_str = f"{temp:.1f}°C" if temp else "N/A"
    return pystray.Menu(
        pystray.MenuItem(f"CPU 占用: {usage:.1f}%", lambda _: None, enabled=False),
        pystray.MenuItem(f"CPU 温度: {temp_str}", lambda _: None, enabled=False),
        pystray.MenuItem("────────────────", lambda _: None, enabled=False),
        pystray.MenuItem("打开监控面板", lambda _: None, enabled=False),
        pystray.MenuItem("关于 KKXX CPU Monitor", lambda _: None, enabled=False),
        pystray.MenuItem("退出", lambda icon, _: icon.stop()),
    )

# ---- 更新线程 ----
class Updater:
    def __init__(self, icon: pystray.Icon, interval=2.0):
        self.icon = icon
        self.interval = interval
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)

    def _loop(self):
        last_usage = 0.0
        last_temp = None
        while self._running:
            try:
                # 避开 psutil 缓存峰值，先请求一次
                usage = psutil.cpu_percent(interval=0.3)
                temp = CPUMonitor.get_cpu_temperature()
                last_usage, last_temp = usage, temp

                temp_str = f"{temp:.1f}°C" if temp else "N/A"
                self.icon.title = f"CPU {usage:.0f}% | {temp_str}"
                self.icon.menu = build_menu(usage, temp)
                self.icon.update_menu()
            except Exception:
                pass
            time.sleep(self.interval)

    def start(self):
        self._thread.start()

    def stop(self):
        self._running = False
        self._thread.join(timeout=2)

# ---- 开机自启 ----
def set_autostart(enable=True):
    name = "KKXX_CPU_Monitor"
    key = winreg.HKEY_CURRENT_USER
    path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        reg_key = winreg.OpenKey(key, path, 0, winreg.KEY_WRITE)
        exe_path = sys.executable
        if enable:
            winreg.SetValueEx(reg_key, name, 0, winreg.REG_SZ, f'"{exe_path}" "{sys.argv[0]}"')
        else:
            try:
                winreg.DeleteValue(reg_key, name)
            except FileNotFoundError:
                pass
        winreg.CloseKey(reg_key)
        return True
    except Exception as e:
        return False

# ---- 主程序 ----
def main():
    # 设置自启（首次运行开启）
    if "--no-autostart" not in sys.argv:
        set_autostart(True)

    usage = psutil.cpu_percent(interval=0.5)
    temp = CPUMonitor.get_cpu_temperature()
    temp_str = f"{temp:.1f}°C" if temp else "N/A"

    menu = build_menu(usage, temp)
    icon = pystray.Icon(
        "cpu_monitor",
        make_icon_text(f"{usage:.0f}"),
        title=f"CPU {usage:.0f}% | {temp_str}",
        menu=menu,
    )

    updater = Updater(icon)
    updater.start()

    try:
        icon.run()
    finally:
        updater.stop()

if __name__ == "__main__":
    main()